import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Test1 {

	@Test
	void test() {
		WordCount test= new WordCount();
		int output= test.count("Hello Wipro");
		assertEquals(2, output);
		
		
	}

}
