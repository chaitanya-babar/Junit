import java.util.Scanner;

public class WordCount {
	
	public int count(String str) {
		Scanner sc= new Scanner(System.in);
		str=sc.nextLine();
		
		int count=0;
		for(int i=0; i<=str.length(); i++) {
			if(str.equals(" ")) {
				count++;
			}
		}
		return count+1;
		
	}

}
