package New;

public class AccountDetails {
	public void acctNo (int a) {
		System.out.println(a);
		
	}

	public void acctName(String str) {
		System.out.println(str);
		
	}
	
	public void acctBalance(int b) {
		System.out.println(b);		
	}

    public void Deposit(int c) {
    	System.out.println(c);
    	
    }
    
    public void Withdraw(int d) {
    	System.out.println(d);
    	
    }
    
    public void creditCard(int e) {
    	System.out.println(e);   	
    }
}
