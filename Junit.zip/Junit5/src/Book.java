import java.util.Scanner;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.junit.Test;
import org.junit.runner.RunWith;
@RunWith(Parameterized.class)
public class Book {
	int price;
	double discount;
	
	Book(int price, double discount){
		this.price=price;
		this.discount=discount;
	}
	public double discountedPrice(int price,double discount) {
		
		double discounted_price=price-((price)*(discount/100));
		return discounted_price;
		
		
				
			
		
		
	}
	@Test
	public void paramdiscount(){
		/*System.out.println("Enter price");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();*/
		Book b=new Book();
		b.discountedPrice();
		
	}

}
